package controllers.MyController;

public class NExtremeAlg {
	
	private double data[];
	
	public NExtremeAlg(double data[]){
		this.data = data;
	}
	
	public double[] copy2Arr(){
		double newData[] = new double[data.length];
		return newData;
	}
	
	public void getNMax() {
		
	}
}
